# !/usr/bin/env python

import requests
import json
from .constants import Constants, HTTPRequestTypes, ErrorMessage


"""
Digispice SMS Connector
API Version : V1
Authentication : Basic Authentication
Connector Version : 1.0.0
"""


class DigispiceTechnologiesConnector (object):
    def __init__(self, username, password, base_url, port,
                 **kwargs):
        """
        This action is used to initialise basic values
        :param username: DigiSpice Username
        :param password: DigiSpice Password
        :param base_url: DigiSpice base_url
        :param port: DigiSpice port
        """

        self.base_url = "{0}:{1}".format (base_url, port)
        self.headers = {'accept': 'application/x-www-form-urlencoded',
                        'content-type': 'application/x-www-form-urlencoded'
                        }
        self.username = username
        self.password = password

    def test_connection(self,
                        **kwargs):
        """
         This method is used to test connectivity of the digispice url
        """
        try:
            url = "{0}".format (self.base_url)
            response = requests.request (HTTPRequestTypes.GET, url)
            if response.status_code < 500:
                return True
            else:
                return False
        except KeyError:
            return False

    def request_handler(self, method, endpoint, data,
                        **kwargs):
        """
        This method handles all requests. We use .text here instead of .json as response is in x-www-form-urlencoded
        :param method: HTTP Method to use
        :param endpoint: Endpoint to make the request to
        :param data: Data to pass in the body of the request [json recommended]
        :return: response formatted in {'result':'response', 'execution_status':'SUCCESS/ ERROR'}
        """

        try:
            endpoint = "{0}/{1}".format (self.base_url, endpoint)
            if method == HTTPRequestTypes.POST:
                response = requests.post (endpoint,
                                          data=json.dumps (data),
                                          headers=self.headers,
                                          auth=(self.username, self.password))
            else:
                method_error = "Invalid Method {0} Requested!.".format (method)
                return {Constants.ACTION_RESULT: method_error,
                        Constants.ACTION_STATUS: Constants.ERROR}
            # need to see example response to accurately assess response codes
            if response.ok:
                response_text = response.text
                return {Constants.ACTION_RESULT: response_text,
                        Constants.ACTION_STATUS: Constants.SUCCESS}
            elif response.status_code == 404:
                response_json = {Constants.ACTION_STATUS: ErrorMessage.RESOURCE_NOT_FOUND,
                                 Constants.ACTION_RESULT: response.json ()}
                return response_json
            else:
                response_error = response.text
                return {Constants.ACTION_RESULT: response_error,
                        Constants.ACTION_STATUS: Constants.ERROR}

        except Exception as e:
            exception_error = str (e)
            return {Constants.ACTION_RESULT: exception_error,
                    Constants.ACTION_STATUS: Constants.ERROR}

    def action_send_sms_message(self, sender_id, mobile, message, intflag, charging, username,
                                **kwargs):
        """
        This action is used to send an SMS to a mobile number
        :param sender_id: Sender CLI
        :param mobile: Receiver Mobile Number
        :param message: Message Text [160 words english max]
        :param intflag: 0 - Domestic | 1 - International
        :param charging: 0 - charging not applicable 1 - charging applicable
        :param username: Digispice User who sends the message
        :return: Status of the action and response
        """
        data = {
            'content_type': 'text',
            'sender_id': sender_id,
            'mobile': mobile,
            'message': message,
            'intflag' : intflag,
            'charging' : charging
        }
        endpoint = "bmg/sms/{username}".format(username = username)
        response = self.request_handler(method =HTTPRequestTypes.POST,
                                        endpoint = endpoint,
                                        data = data)
        return response
