# constants.py

class Constants ():
    """
    Application Constants.
    """

    ACTION_RESULT = "result"
    ACTION_STATUS = "execution_status"
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"


class ErrorMessage ():
    """
    Connector Error Messages.
    """

    SERVER_ERROR = "Server Error, try again"
    RESOURCE_NOT_FOUND = "Resource not Found"


class HTTPRequestTypes ():
    """
    HTTP Request Methods:
    GET     - The GET method is used to retrieve information from the given server using a given URI.
    POST    - A POST request is used to send data to the server using HTML forms.
    """

    GET = "GET"
    POST = "POST"
